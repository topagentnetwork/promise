open Jest
open Expect
open Date

let () =
  let d = Date.make ~utc:true ~year:2019 ~month:1 ~date:13 () in
  let date = Date.start_of_day d in
  describe "Adding days" (fun () ->
      test "add days" (fun () ->
          let date2 = Date.make ~utc:true ~year:2019 ~month:1 ~date:23 () in
          let date2' = Date.start_of_day date2 in
          expect (add_days ~days:10 date) |> toEqual date2')) ;
  describe "Subtracting days" (fun () ->
      test "sub days" (fun () ->
          let date2 = Date.make ~utc:true ~year:2019 ~month:1 ~date:3 () in
          let date2' = Date.start_of_day date2 in
          expect (sub_days ~days:10 date) |> toEqual date2')) ;
  describe "Adding hours" (fun () ->
      test "add hours" (fun () ->
          let date = Date.make ~utc:true ~year:2019 ~month:1 ~date:23 () in
          let date' = add_hours ~hours:3 date in
          expect (difference_in_hours date' date) |> toEqual 3)) ;
  describe "Substract hours" (fun () ->
      test "substract hours" (fun () ->
          let date = Date.make ~utc:true ~year:2019 ~month:1 ~date:23 () in
          let date' = sub_hours ~hours:3 date in
          expect (difference_in_hours date date') |> toEqual 3)) ;
  describe "formatting" (fun () ->
      test "it should format" (fun () ->
          expect
          @@ format_to_tmz
               ~fmt_config:(timezone_config ~timeZone:"America/Los_Angeles" ())
               ~fmt:"YYYY/M/DD" d
          |> toEqual "2019/1/12")) ;
  describe "make" (fun () ->
      test "make utc date" (fun () ->
          expect
            (make ~utc:true ~year:2019 ~month:1 ~date:13 () |> to_iso_string)
          |> toMatchSnapshot)) ;
  describe "parse_from_tmz" (fun () ->
      test "parse" (fun () ->
          let d =
            parse_from_tmz
              ~options:(timezone_config ~timeZone:"America/Los_Angeles" ())
              "2019/1/12" in
          let d' =
            format_to_tmz
              ~fmt_config:(timezone_config ~timeZone:"America/Los_Angeles" ())
              ~fmt:"YYYY/M/DD" d in
          expect d' |> toEqual "2019/1/12") ;
      test "parse with time" (fun () ->
          let d =
            parse_from_tmz
              ~options:(timezone_config ~timeZone:"America/Chicago" ())
              "2019/7/9 17:00:00" in
          let d' =
            format_to_tmz
              ~fmt_config:(timezone_config ~timeZone:"America/Chicago" ())
              ~fmt:"YYYY/M/DD HH:mm:ss (z)" d in
          expect d' |> toEqual "2019/7/09 17:00:00 (CDT)")) ;
  describe "is_after" (fun () ->
      test "returns true if the date is after" (fun () ->
          let date' = Date.add_days ~days:1 date in
          expect (Date.is_after date' date) |> toBe true) ;
      test "returns false if the date is before" (fun () ->
          let date' = Date.sub_days ~days:1 date in
          expect (Date.is_after date' date) |> toBe false)) ;
  describe "is_before" (fun () ->
      test "returns false if the date is after" (fun () ->
          let date' = Date.add_days ~days:1 date in
          expect (Date.is_before date' date) |> toBe false) ;
      test "returns true if the date is before" (fun () ->
          let date' = Date.sub_days ~days:1 date in
          expect (Date.is_before date' date) |> toBe true)) ;
  describe "start_of_day" (fun () ->
      test "it should change the hour to 0" (fun () ->
          let sod = start_of_day d in
          expect (Js.Date.getHours sod) |> toEqual 0.) ;
      test "it should change the minutes to 0" (fun () ->
          let sod = start_of_day d in
          expect (Js.Date.getMinutes sod) |> toEqual 0.)) ;
  describe "end_of_day" (fun () ->
      test "it should change the hour to 23" (fun () ->
          let eod = end_of_day d in
          expect (Js.Date.getHours eod) |> toEqual 23.) ;
      test "it should change the minutes to 59" (fun () ->
          let eod = end_of_day d in
          expect (Js.Date.getMinutes eod) |> toEqual 59.)) ;
  describe "unix timestamps" (fun () ->
      let date = Date.make ~utc:true ~year:2019 ~month:1 ~date:23 () in
      test "it should convert to a unix timestamp" (fun () ->
          expect @@ to_unix_timestamp date |> toMatchSnapshot) ;
      test "it should convert from a unix timestamp" (fun () ->
          expect @@ from_unix_timestamp 1548201600 |> toEqual date))
