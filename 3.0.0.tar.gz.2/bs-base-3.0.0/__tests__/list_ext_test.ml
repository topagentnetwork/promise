open Jest
open Expect

type element = {id: int; user_id: int}

type user = {id: int}

let make_user () = {id= Js.Math.random_int 1 10_000}

let make_element ~user_id = {id= Js.Math.random_int 1 10_000; user_id}

let make_element_list () =
  let user1 = make_user () in
  let user2 = make_user () in
  let user3 = make_user () in
  ( user1
  , user2
  , user3
  , [ make_element ~user_id:user1.id
    ; make_element ~user_id:user1.id
    ; make_element ~user_id:user1.id
    ; make_element ~user_id:user2.id
    ; make_element ~user_id:user2.id
    ; make_element ~user_id:user3.id ] )

let () =
  describe "filter_map" (fun () ->
      test "should filter out the nones after applying supplied function"
        (fun () ->
          expect (List_ext.filter_map ~f:Fn.id [Some 1; Some 2; None; Some 3])
          |> toEqual [1; 2; 3] ) ) ;
  describe "filter_opt" (fun () ->
      test "should filter out the nones" (fun () ->
          expect (List_ext.filter_opt [Some 1; Some 2; None; Some 3])
          |> toEqual [1; 2; 3] ) ) ;
  describe "join_ints" (fun () ->
      test "should join them by default with comma" (fun () ->
          expect (List_ext.join_ints [1; 2; 3]) |> toEqual "1,2,3" ) ;
      test "support specifying a separator" (fun () ->
          expect (List_ext.join_ints ~sep:"-" [1; 2; 3]) |> toEqual "1-2-3" )
  ) ;
  describe "hd" (fun () ->
      test "should return None for empty lists" (fun () ->
          expect @@ List_ext.hd [] |> toEqual None ) ;
      test "should return some of the head of list for non-empty lists"
        (fun () ->
          expect @@ List_ext.hd ["Tokyo"; "Los Angeles"]
          |> toEqual (Some "Tokyo") ) ) ;
  describe "find" (fun () ->
      test "should return None for empty lists" (fun () ->
          expect @@ List_ext.find ~f:(fun e -> e = 1) [] |> toEqual None ) ;
      test
        "it should return None if the predicate fails for every element of \
         the list" (fun () ->
          expect @@ List_ext.find ~f:(fun e -> e > 10) [1; 2; 3; 4]
          |> toEqual None ) ;
      test
        "should return some of the first found element satisfying the \
         predication" (fun () ->
          expect
          @@ List_ext.find
               ~f:(fun e -> e = "Kyoto")
               ["Tokyo"; "Los Angeles"; "Kyoto"]
          |> toEqual (Some "Kyoto") ) ) ;
  describe "group_by" (fun () ->
      test
        "it should group the elements in the list by the result of the \
         supplied function" (fun () ->
          let user1, _user2, _user3, l = make_element_list () in
          let groups = List_ext.group_by ~f:(fun e -> e.user_id) l in
          expect @@ (Hashtbl.find groups user1.id |> List.sort compare)
          |> toEqual
               ( List.filter (fun e -> e.user_id = user1.id) l
               |> List.sort compare ) ) )
