open Jest
open Expect
open Result
open Promise_result.Infix

let f v = Promise.resolved (Ok ("Hello " ^ v))

let f' v = "Hello " ^ v

let () =
  describe "return" (fun () ->
      testPromise "it should return a resolved Ok promise" (fun () ->
          Promise_result.return "Testing"
          |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok s ->
                       expect s |> toEqual "Testing" |> resolve
                   | Error _ ->
                       resolve (fail "it should have been an Ok") )) ) ) ;
  describe "bind" (fun () ->
      testPromise
        "it should apply the function to the Ok value without rewrapping it"
        (fun () ->
          Promise.resolved (Ok "OCaml")
          |> Promise_result.bind ~f |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok s ->
                       expect s |> toEqual "Hello OCaml" |> resolve
                   | Error _ ->
                       resolve (fail "it should have been a Result.Ok") )) ) ) ;
  describe "map" (fun () ->
      testPromise "it should map the function to the Ok value" (fun () ->
          Promise.resolved (Ok "OCaml")
          |> Promise_result.map ~f:f' |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok s ->
                       expect s |> toEqual "Hello OCaml" |> resolve
                   | Error _ ->
                       resolve (fail "it should have been a Result.Ok") )) ) ) ;
  describe "map_error" (fun () ->
      testPromise "it should map the function to the Error value" (fun () ->
          Promise.resolved (Error "Error")
          |> Promise_result.map_error ~f:f'
          |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok _ ->
                       resolve (fail "it should have been a Result.Error")
                   | Error e ->
                       expect e |> toEqual "Hello Error" |> resolve )) ) ) ;
  describe "all" (fun () ->
      testPromise "it should accumulate the results" (fun () ->
          Promise_result.all
            [Promise_result.return "one"; Promise_result.return "two"]
          |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok results ->
                       expect results |> toEqual ["one"; "two"] |> resolve
                   | Error e ->
                       resolve (fail @@ Error.to_string e) )) ) ) ;
  describe "infix operator" (fun () ->
      testPromise ">>| should map" (fun () ->
          Promise.resolved (Ok "Infix")
          >>| f' |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok s ->
                       expect s |> toEqual "Hello Infix" |> resolve
                   | Error _ ->
                       resolve (fail "it should have been a Result.OK") )) ) ;
      testPromise ">>= should bind" (fun () ->
          Promise.resolved (Ok "Infix")
          >>= f |> Promise.Rejectable.toJsPromise
          |> Js.Promise.(
               then_ (fun v ->
                   match v with
                   | Ok s ->
                       expect s |> toEqual "Hello Infix" |> resolve
                   | Error _ ->
                       resolve (fail "it should have been a Result.OK") )) ) )
