open Jest
open Expect
open Comparator_util.Infix

type r = {a: string; b: int; c: string; d: Js.Date.t}

let cmp r1 r2 =
  compare r1.a r2.a <?> (compare, r1.b, r2.b) <?> (compare, r1.c, r2.c)
  <?> (compare, r1.d, r2.d)

let () =
  describe "Infix" (fun () ->
      describe "<?>" (fun () ->
          let date = Js.Date.make () in
          let r1 = {a= "test"; b= 1; c= "testing"; d= date} in
          let r2 = {a= "test"; b= 1; c= "testing"; d= date} in
          let r3 = {a= "blah"; b= 2; c= "testing"; d= date} in
          test "should return 0 when the supplied fields all compare to 0"
            (fun () -> expect @@ cmp r1 r2 |> toEqual 0) ;
          test
            "should return 1 when the first field in first record is greater \
             than its equivalent in the second record" (fun () ->
              expect @@ cmp r1 r3 |> toEqual 1 ) ) )
