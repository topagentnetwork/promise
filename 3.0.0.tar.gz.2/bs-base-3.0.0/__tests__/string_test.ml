open Jest
open Expect
open String_ext

let () =
  describe "is_empty" (fun () ->
      test "should return true for empty strings" (fun () ->
          expect (is_empty "") |> toBe true ) ;
      test "should return false for non-empty strings" (fun () ->
          expect (is_empty "string") |> toBe false ) )
