open Jest
open Expect
open Error

let () =
  describe "has_tag" (fun () ->
      test "it should return true when the error has the specified tag"
        (fun () ->
          let error = of_string "String error" in
          let tag_error = tag ~tag:"test-tag" error in
          expect @@ has_tag ~tag:"test-tag" tag_error |> toEqual true ) ;
      test
        "it should return false when the error does not have the specified tag"
        (fun () ->
          let error = of_string "String error" in
          let tag_error = tag ~tag:"random" error in
          expect @@ has_tag ~tag:"test-tag" tag_error |> toEqual false ) ;
      test "it should return false for non-tagged errors" (fun () ->
          let error = of_string "String error" in
          expect @@ has_tag ~tag:"test-tag" error |> toEqual false ) ) ;
  describe "Converting error to string" (fun () ->
      test "it should convert a simple string error" (fun () ->
          let error = of_string "String error" in
          expect @@ to_string error |> toEqual "String error" ) ;
      test "it should convert a tagged error" (fun () ->
          let error = of_string "String error" in
          let tag_error = tag ~tag:"server" error in
          expect @@ to_string tag_error |> toMatchSnapshot ) ;
      test "it should convert a js exception error" (fun () ->
          try Js.Exn.raiseError "Some error"
          with Js.Exn.Error e ->
            let error = of_js_exn e in
            expect @@ to_string error |> toMatchRe [%re "/Object.raiseError/"]
      ) ) ;
  describe "Converting a list of errors to string" (fun () ->
      try Js.Exn.raiseError "Some error"
      with Js.Exn.Error e ->
        let exn_error = of_js_exn e in
        let error = of_string "string error" in
        let tag_error = tag ~tag:"server" error in
        let error' = of_string "another error" in
        let tag_error' = tag ~tag:"redis" error' in
        let tag_exn_error = tag ~tag:"exn" exn_error in
        let errors = of_list [tag_error; tag_error'; tag_exn_error] in
        let error_s = to_string errors in
        let tag_error_s = to_string tag_error in
        test "it should include the js exception" (fun () ->
            expect error_s |> toMatchRe [%re "/Object.raiseError/"] ) ;
        test "it should include the tagged error" (fun () ->
            expect error_s |> toMatchRe @@ Js.Re.fromString tag_error_s ) ) ;
  describe "Raising error" (fun () ->
      test "it should raise an error exception" (fun () ->
          let error = Error.of_string "Exception" in
          expect (fun () -> Error.raise error)
          |> toThrowMessageRe [%re "/Exception/"] ) )
