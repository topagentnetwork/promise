open Jest
open Expect
open Result
open Result.Infix

let () =
  describe "is_ok" (fun () ->
      test "it should return true for Ok values" (fun () ->
          expect @@ is_ok (Ok "test") |> toBe true ) ;
      test "it should return false for Error values" (fun () ->
          expect @@ is_ok (Error "error") |> toBe false ) ) ;
  describe "is_error" (fun () ->
      test "it should return false for Ok values" (fun () ->
          expect @@ is_error (Ok "test") |> toBe false ) ;
      test "it should return true for Error values" (fun () ->
          expect @@ is_error (Error "error") |> toBe true ) ) ;
  describe "map" (fun () ->
      test "it should map ok values" (fun () ->
          let o = Ok "test" in
          expect @@ map ~f:(fun e -> e ^ " works") o
          |> toEqual (Ok "test works") ) ;
      test "it should just return the error" (fun () ->
          let e = Error "error" in
          expect @@ map ~f:(fun _ -> "does not apply") e |> toEqual e ) ) ;
  describe "bind" (fun () ->
      test "it should bind ok values" (fun () ->
          let o = Ok "test" in
          expect @@ bind ~f:(fun e -> Ok (e ^ " works")) o
          |> toEqual (Ok "test works") ) ;
      test "it should just return the error" (fun () ->
          let e = Error "error" in
          expect @@ bind ~f:(fun _ -> Ok "does not apply") e |> toEqual e ) ) ;
  describe "of_option" (fun () ->
      test "it should convert some to an ok" (fun () ->
          let o = Some "test" in
          expect @@ of_option ~error:"error" o |> toEqual (Ok "test") ) ;
      test "it should convert a none to the supplied error" (fun () ->
          expect @@ of_option ~error:"error" None |> toEqual (Error "error") )
  ) ;
  describe "value_or" (fun () ->
      test "it should return the OK value" (fun () ->
          let r = Ok "good value" in
          expect @@ value_or ~default:"bad value" r |> toEqual "good value" ) ;
      test "it should return the default for an Error value" (fun () ->
          let r = Error () in
          expect @@ value_or ~default:"bad value" r |> toEqual "bad value" ) ) ;
  describe "all" (fun () ->
      test "with a list of Oks" (fun () ->
          let results = [Ok "one"; Ok "two"; Ok "three"] in
          expect @@ all results |> toEqual (Ok ["one"; "two"; "three"]) ) ;
      test "it should return the first error with a list of errors" (fun () ->
          let results =
            [Ok "one"; Error "Some error"; Ok "two"; Error "Another error"]
          in
          expect @@ all results |> toEqual (Error "Some error") ) ) ;
  describe "apply" (fun () ->
      test "it should apply ok functions" (fun () ->
          let f e = e ^ " works" in
          expect @@ apply (Ok f) (Ok "Test") |> toEqual (Ok "Test works") ) ;
      test "it should return Error if f is an error" (fun () ->
          expect @@ apply (Error "error") (Ok "test")
          |> toEqual (Error "error") ) ) ;
  describe "map_error" (fun () ->
      test "it should map the error" (fun () ->
          let r = Error "test" in
          expect @@ map_error ~f:(fun e -> "map " ^ e) r
          |> toEqual (Error "map test") ) ) ;
  describe "infix operators" (fun () ->
      test ">>= should bind" (fun () ->
          let o = Ok "test" in
          let f e = Ok (e ^ " works") in
          expect (o >>= f) |> toEqual (Ok "test works") ) ;
      test " >>| should map" (fun () ->
          let o = Ok "test" in
          let f e = e ^ " works" in
          expect (o >>| f) |> toEqual (Ok "test works") ) ;
      test " <*> should apply" (fun () ->
          let rf = Ok (fun e -> e ^ " works") in
          let o = Ok "test" in
          expect (rf <*> o) |> toEqual (Ok "test works") ) )
