open Jest
open Expect

let () =
  describe "compose" (fun () ->
      test "given arguments f g x it should call f (g x)" (fun () ->
          let f x = "hello " ^ string_of_int x in
          let g x = x + 10 in
          let f' = Fn.compose f g in
          expect @@ f' 5 |> toEqual "hello 15" ) ) ;
  describe "const" (fun () ->
      test "it should return a function that returns the supplied argument"
        (fun () ->
          let x = "my value" in
          let y = Fn.const x in
          expect @@ y () |> toBe x ) ) ;
  describe "flip" (fun () ->
      test "it should flip the arguments of a binary function" (fun () ->
          let f a b = a ^ " " ^ b in
          let f' = Fn.flip f in
          expect @@ f' "Hello" "World" |> toEqual "World Hello" ) ) ;
  describe "id" (fun () ->
      test "it should return the passed in argument" (fun () ->
          let x = 10 in
          expect @@ Fn.id x |> toBe x ) )
