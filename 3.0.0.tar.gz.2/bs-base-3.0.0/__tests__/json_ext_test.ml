open Jest
open Expect
open Json_ext

let invalid_json = {js|
    { "key": "value", }
|js}

let () =
  describe "safe_json_parse" (fun () ->
      test "it should not throw exception for invalid json" (fun () ->
          expect @@ (safe_json_parse invalid_json |> Result.is_error)
          |> toBe true ) ;
      test "it should generate an error with the js exception" (fun () ->
          expect @@ safe_json_parse invalid_json |> toMatchSnapshot ) )
