open Jest
open Expect
open Option
open Option.Infix

let map_f o = o ^ " works"

let bind_f o = Some (o ^ " works")

let () =
  describe "is_none" (fun () ->
      test "it should return true for none" (fun () ->
          expect @@ is_none None |> toBe true ) ;
      test "it should return false for some" (fun () ->
          expect @@ is_none (Some "test") |> toBe false ) ) ;
  describe "is_some" (fun () ->
      test "it should return false for none" (fun () ->
          expect @@ is_some None |> toBe false ) ;
      test "it should return false for some" (fun () ->
          expect @@ is_some (Some "test") |> toBe true ) ) ;
  describe "map" (fun () ->
      test "it should map some values" (fun () ->
          let s = Some "test" in
          expect (map ~f:map_f s) |> toEqual (Some "test works") ) ;
      test "it should return none" (fun () ->
          expect (map ~f:map_f None) |> toEqual None ) ) ;
  describe "bind" (fun () ->
      test "it should bind some values" (fun () ->
          let s = Some "test" in
          expect (bind ~f:bind_f s) |> toEqual (Some "test works") ) ;
      test "it should return none" (fun () ->
          expect (map ~f:bind_f None) |> toEqual None ) ) ;
  describe "value_map" (fun () ->
      test "it should apply fn to some values" (fun () ->
          let s = Some "test" in
          expect (value_map ~default:"default" ~f:map_f s)
          |> toEqual "test works" ) ;
      test "it should return the default to none values" (fun () ->
          expect (value_map ~default:"default" ~f:map_f None)
          |> toEqual "default" ) ) ;
  describe "value" (fun () ->
      test "it should return value of the some" (fun () ->
          let s = Some "test" in
          expect (value ~default:"default" s) |> toEqual "test" ) ;
      test "it should return the default to none values" (fun () ->
          expect (value ~default:"default" None) |> toEqual "default" ) ) ;
  describe "infix operators" (fun () ->
      test ">>= should bind" (fun () ->
          let o = Some "test" in
          expect (o >>= bind_f) |> toEqual (Some "test works") ) ;
      test " >>| should map" (fun () ->
          let o = Some "test" in
          expect (o >>| map_f) |> toEqual (Some "test works") ) ) ;
  describe "value_err" (fun () ->
      test "it should return the value of the some" (fun () ->
          let s = Some "test" in
          expect (value_exn ~error:"" s) |> toEqual "test" ) ;
      test "it should raise an exception for none" (fun () ->
          expect (fun () -> value_exn ~error:"Raise Error" None)
          |> toThrowMessageRe [%re "/Raise Error/"] ) )
