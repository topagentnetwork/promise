include Monad_t_intf

module Custom_extend
    (Mt : MonadT)
    (A : Applicative.Applicative with type 'a t = 'a Mt.t)
    (F : Functor.Functor with type 'a t = 'a Mt.t) :
  Extended with type 'a t = 'a Mt.t and type 'a m = 'a Mt.m = struct
  include Mt
  module M = Monad.Custom_extend (Mt) (A) (F)
  include (M : Monad.Extended with type 'a t := 'a t)
end

module Extend (Mt : MonadT) :
  Extended with type 'a t = 'a Mt.t and type 'a m = 'a Mt.m =
  Custom_extend (Mt) (Monad.Make_applicative (Mt)) (Monad.Make_functor (Mt))
