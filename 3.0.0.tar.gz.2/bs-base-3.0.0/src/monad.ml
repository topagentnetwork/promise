include Monad_intf

module Make_applicative (M : Monad) :
  Applicative.Applicative with type 'a t = 'a M.t = struct
  open M

  type 'a t = 'a M.t

  let pure = return
  let ap ~f x = bind ~f:(fun f' -> bind ~f:(fun x' -> return (f' x')) x) f
end

module Make_functor (M : Monad) : Functor.Functor with type 'a t = 'a M.t =
struct
  open M

  type 'a t = 'a M.t

  let map ~f x = bind ~f:(fun x' -> return @@ f x') x
end

module Custom_extend
    (M : Monad)
    (A : Applicative.Applicative with type 'a t = 'a M.t)
    (F : Functor.Functor with type 'a t = 'a M.t) :
  Extended with type 'a t = 'a M.t = struct
  module A = Applicative.Custom_extend (A) (F)
  include M

  module Infix = struct
    include A.Infix

    let ( >>= ) m f = bind m ~f
    let ( =<< ) f m = bind m ~f
    let ( >=> ) f g x = f x >>= g
    let ( <=< ) f g = g >=> f
  end

  include (
    A : Applicative.Extended with type 'a t := 'a t and module Infix := Infix )

  open Infix

  let lift_m = map
  let lift_m2 ~f m1 m2 = m1 >>= fun x1 -> m2 >>= fun x2 -> return (f x1 x2)

  let lift_m3 ~f m1 m2 m3 =
    m1 >>= fun x1 -> m2 >>= fun x2 -> m3 >>= fun x3 -> return (f x1 x2 x3)
end

module Extend (M : Monad) : Extended with type 'a t = 'a M.t =
  Custom_extend (M) (Make_applicative (M)) (Make_functor (M))
