type ('f, 's) t = First of 'f | Second of 's

let first x = First x
let second x = Second x
