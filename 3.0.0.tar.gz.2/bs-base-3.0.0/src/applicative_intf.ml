module type Applicative = sig
  type 'a t

  val pure : 'a -> 'a t
  val ap : f:('a -> 'b) t -> 'a t -> 'b t
end

module type Infix = sig
  type 'a t

  include Functor.Infix with type 'a t := 'a t

  val ( <*> ) : ('a -> 'b) t -> 'a t -> 'b t
  val ( *> ) : 'a t -> 'b t -> 'b t
  val ( <* ) : 'a t -> 'b t -> 'a t
end

module type Extended = sig
  include Applicative
  module Infix : Infix with type 'a t := 'a t
  include Functor.Extended with type 'a t := 'a t and module Infix := Infix

  val lift_a : f:('a -> 'b) -> 'a t -> 'b t
  val lift_a2 : f:('a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t
  val lift_a3 : f:('a -> 'b -> 'c -> 'd) -> 'a t -> 'b t -> 'c t -> 'd t
end

module type S = sig
  module type Applicative = Applicative
  module type Infix = Infix
  module type Extended = Extended

  module Extend (A : Applicative) : Extended with type 'a t = 'a A.t

  module Custom_extend
      (A : Applicative)
      (F_ : Functor.Functor with type 'a t = 'a A.t) :
    Extended with type 'a t = 'a A.t

  module Make_functor (A : Applicative) :
    Functor.Functor with type 'a t = 'a A.t
end
