let compose f g x = f (g x)
let const x _ = x
let flip f x y = f y x
let uncurry2 fn (a, b) = fn a b
let uncurry3 fn (a, b, c) = fn a b c
let uncurry4 fn (a, b, c, d) = fn a b c d
let uncurry5 fn (a, b, c, d, e) = fn a b c d e
let uncurry6 fn (a, b, c, d, e, f) = fn a b c d e f
let uncurry = uncurry2

external id : 'a -> 'a = "%identity"

module Infix = struct let ( % ) = compose end
