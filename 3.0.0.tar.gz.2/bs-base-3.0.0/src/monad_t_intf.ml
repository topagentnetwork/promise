module type MonadT = sig
  include Monad.Monad

  type 'a m

  val lift : 'a m -> 'a t
end

module type Infix = Monad.Infix

module type Extended = sig
  include MonadT
  module Infix : Infix with type 'a t := 'a t
  include Monad.Extended with type 'a t := 'a t and module Infix := Infix
end

module type S = sig
  module type MonadT = MonadT
  module type Infix = Infix
  module type Extended = Extended

  module Extend (M : MonadT) :
    Extended with type 'a t = 'a M.t and type 'a m = 'a M.m

  module Custom_extend
      (M : MonadT)
      (A : Applicative.Applicative with type 'a t = 'a M.t)
      (F : Functor.Functor with type 'a t = 'a M.t) :
    Extended with type 'a t = 'a M.t and type 'a m = 'a M.m
end
