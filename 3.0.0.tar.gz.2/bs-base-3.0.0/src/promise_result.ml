open Result

type ('a, 'b) t = ('a, 'b) Result.t Promise.t

let return a = Promise.resolved (Ok a)
let error e = Promise.resolved (Error e)
let of_result r = match r with Ok ok -> return ok | Error e -> error e

let bind ~f t =
   Promise.flatMap t (fun p ->
         match p with Ok r -> f r | Error e -> Promise.resolved (Error e))

let map ~f t =
    Promise.map t (fun p ->
         match p with Ok r -> Ok (f r) | Error e -> Error e)

let map_error ~f t =
   Promise.map t  (fun p ->
         match p with Ok _ as ok -> ok | Error e -> Error (f e))

let all p =   Promise.map (Promise.all p) Result.all
let all2 a b = Promise.all2 a b |. Promise.map (Fn.uncurry2 Result.all2)
let all3 a b c = Promise.all3 a b c |. Promise.map (Fn.uncurry3 Result.all3)

let all4 a b c d =
  Promise.all4 a b c d |. Promise.map (Fn.uncurry4 Result.all4)

let all5 a b c d e =
  Promise.all5 a b c d e |. Promise.map (Fn.uncurry5 Result.all5)

let all6 a b c d e f =
  Promise.all6 a b c d e f |. Promise.map (Fn.uncurry6 Result.all6)

module Infix = struct
  let ( >>= ) t f = bind ~f t
  let ( >>| ) t f = map ~f t
  let ( <$> ) f t = map ~f t

  let ( <*> ) f t =
    Promise.flatMap
      f
      (function Ok f' -> f' <$> t | Error _ as e -> Promise.resolved e)
end
