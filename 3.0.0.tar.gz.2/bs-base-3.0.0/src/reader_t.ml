module type Reader_monad_t = sig
  type env

  include Monad_t.Extended

  val ask : env t
  val local : f:(env -> env) -> 'a t -> 'a t
  val run_reader_t : env:env -> 'a t -> 'a m
  val reader_t : (env -> 'a m) -> 'a t
end

module Make
    (M : Monad.Monad) (S : sig
      type t
    end) : Reader_monad_t with type env = S.t and type 'a m = 'a M.t = struct
  type env = S.t

  include Monad_t.Extend (struct
    type 'a m = 'a M.t
    type 'a t = env -> 'a m

    let return a _ = M.return a
    let bind ~f m e = M.bind ~f:(fun a -> f a e) (m e)
    let lift m _ = m
  end)

  let run_reader_t ~env m = m env
  let reader_t = Fn.id
  let ask = M.return
  let local ~f m = Fn.compose m f
end
