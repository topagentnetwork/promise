open Result

type t = Js.Json.t

let safe_json_parse json =
  try
    let json' = Js.Json.parseExn json in
    Ok json'
  with
  | Js.Exn.Error e -> Error (Error.of_js_exn e)
  | _ -> Error (Error.of_string "Json parse error")
