type 'a t = 'a list

let join ?(sep = ",") ?(init = "") t =
  List.fold_left
    (fun a e -> if String.length a > 0 then String.concat sep [a; e] else e)
    init t

let join_ints ?(sep = ",") ?(init = "") t =
  List.map string_of_int t |> join ~sep ~init

let is_empty t = List.length t = 0

let hd t =
  try
    let e = List.hd t in
    Some e
  with _ -> None

let find ~f t =
  try
    let e = List.find f t in
    Some e
  with _ -> None

let filter_map ~f t =
  List.fold_left (fun a e -> match f e with Some x -> x :: a | None -> a) [] t
  |> List.rev

let filter_opt t = filter_map ~f:Fn.id t

let group_by ~f t =
  List.fold_left
    (fun acc e ->
      let grp = f e in
      let grp_mems = try Hashtbl.find acc grp with Not_found -> [] in
      Hashtbl.replace acc grp (e :: grp_mems) ;
      acc)
    (Hashtbl.create 100) t
