module type Reader_monad = sig
  type env
  type 'a t

  include Monad.Extended with type 'a t := 'a t

  val ask : env t
  val local : f:(env -> env) -> 'a t -> 'a t
  val run_reader : env:env -> 'a t -> 'a
  val reader : (env -> 'a) -> 'a t
end

module Make (S : sig
  type t
end) =
struct
  include Reader_t.Make (Identity) (S)

  let run_reader = run_reader_t
  let reader = reader_t
end
