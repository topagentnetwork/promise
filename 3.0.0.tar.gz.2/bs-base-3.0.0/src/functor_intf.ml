module type Functor = sig
  type 'a t

  val map : f:('a -> 'b) -> 'a t -> 'b t
end

module type Infix = sig
  type 'a t

  val ( <$> ) : ('a -> 'b) -> 'a t -> 'b t
  (** A convenient shorthand for map *)

  val ( <$ ) : 'a -> 'b t -> 'a t
  val ( $> ) : 'a t -> 'b -> 'b t
end

module type Extended = sig
  include Functor
  module Infix : Infix with type 'a t := 'a t

  val void : f:('a -> 'b) -> 'a t -> unit t
end

module type S = sig
  module type Functor = Functor
  module type Infix = Infix
  module type Extended = Extended

  module Extend (F : Functor) : Extended with type 'a t = 'a F.t
end
