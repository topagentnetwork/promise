include Applicative_intf

module Make_functor (A : Applicative) :
  Functor.Functor with type 'a t = 'a A.t = struct
  type 'a t = 'a A.t

  let map ~f x = A.ap ~f:(A.pure f) x
end

module Custom_extend
    (A : Applicative)
    (F : Functor.Functor with type 'a t = 'a A.t) :
  Extended with type 'a t = 'a A.t = struct
  include A
  module F = Functor.Extend (F)

  module Infix = struct
    include F.Infix

    let ( <*> ) mf mx = ap ~f:mf mx
    let ( *> ) r x = (fun _ y -> y) <$> r <*> x
    let ( <* ) r x = Fn.const <$> r <*> x
  end

  include (F : Functor.Extended with type 'a t := 'a t and module Infix := Infix)
  open Infix

  let lift_a ~f x = f <$> x
  let lift_a2 ~f x y = f <$> x <*> y
  let lift_a3 ~f x y z = f <$> x <*> y <*> z
end

module Extend (A : Applicative) : Extended with type 'a t = 'a A.t =
  Custom_extend (A) (Make_functor (A))
