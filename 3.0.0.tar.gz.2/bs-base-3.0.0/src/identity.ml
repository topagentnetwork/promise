module Identity_monad = struct
  type 'a t = 'a

  let return = Fn.id
  let bind ~f m = f m
end

include Monad.Extend (Identity_monad)
