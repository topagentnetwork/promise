type t = Js.Exn.t

let to_s e =
  let name =
    Option.value_map ~default:"(Nameless JS exception)"
      ~f:(fun n -> n ^ ": ")
      (Js.Exn.name e) in
  let message =
    Option.value ~default:name
    @@ Option.map ~f:(fun m -> name ^ " " ^ m) (Js.Exn.message e) in
  Option.value ~default:name
  @@ Option.map ~f:(fun s -> message ^ "\n" ^ s) (Js.Exn.stack e)
