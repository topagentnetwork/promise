type ('a, 'b) t = ('a, 'b) Stdlib.result = Ok of 'a | Error of 'b

let is_ok = function Ok _ -> true | Error _ -> false
let is_error = function Ok _ -> false | Error _ -> true
let ok = function Ok x -> Some x | Error _ -> None
let error = function Ok _ -> None | Error x -> Some x
let pure v = Ok v
let of_option ~error opt = match opt with Some x -> Ok x | None -> Error error
let map ~f t = match t with Error _ as x -> x | Ok x -> Ok (f x)

let apply rf t =
  match (rf, t) with Ok f, t -> map ~f t | Error e, _ -> Error e

let map_error ~f t = match t with Ok _ as x -> x | Error x -> Error (f x)
let bind ~f t = match t with Error _ as x -> x | Ok x -> f x
let return x = Ok x
let iter ~f v = match v with Ok x -> f x | Error _ -> ()
let iter_error ~f v = match v with Ok _ -> () | Error x -> f x
let value_or ~default = function Ok v -> v | Error _ -> default

let from_belt_result = function
  | Belt.Result.Ok o -> Ok o
  | Belt.Result.Error e -> Error e

let to_belt_result = function
  | Ok o -> Belt.Result.Ok o
  | Error e -> Belt.Result.Error e

module Infix = struct
  let ( >>= ) t f = bind ~f t
  let ( >>| ) t f = map ~f t
  let ( <*> ) f t = apply f t
  let ( <$> ) f t = map ~f t
end

let all =
  let open Infix in
  let rec loop vs = function
    | [] -> return (List.rev vs)
    | t :: ts -> t >>= fun v -> loop (v :: vs) ts in
  fun ts -> loop [] ts

let all2 a b =
  let open Infix in
  a >>= fun a' -> b >>| fun b' -> (a', b')

let all6 a b c d e f =
  let open Infix in
  a
  >>= fun a' ->
  b
  >>= fun b' ->
  c
  >>= fun c' ->
  d >>= fun d' -> e >>= fun e' -> f >>| fun f' -> (a', b', c', d', e', f')

let ignore = pure None

let all3 a b c =
  map ~f:(fun (a', b', c', _, _, _) -> (a', b', c'))
  @@ all6 a b c ignore ignore ignore

let all4 a b c d =
  map ~f:(fun (a', b', c', d', _, _) -> (a', b', c', d'))
  @@ all6 a b c d ignore ignore

let all5 a b c d e =
  map ~f:(fun (a', b', c', d', e', _) -> (a', b', c', d', e'))
  @@ all6 a b c d e ignore
