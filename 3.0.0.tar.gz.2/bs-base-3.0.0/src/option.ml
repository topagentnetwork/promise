type 'a t = 'a option

exception Missing_value of string

let is_none = function None -> true | _ -> false
let is_some = function Some _ -> true | _ -> false
let value_map ~default ~f o = match o with Some x -> f x | None -> default
let value ~default o = match o with Some x -> x | None -> default

let value_exn ~error o =
  match o with Some x -> x | None -> raise (Missing_value error)

let some x = Some x
let return = some
let map ~f t = match t with None -> None | Some a -> Some (f a)
let bind ~f o = match o with None -> None | Some x -> f x
let pure = some
let empty = None

module Infix = struct
  let ( >>= ) t f = bind ~f t
  let ( >>| ) t f = map ~f t
  let ( <$> ) f t = map ~f t
  let ( <*> ) f t = match f with Some f' -> map ~f:f' t | None -> None
  let ( <|> ) a b = match a with Some _ as a' -> a' | None -> b
end
