type t = string

let is_empty t = String.length t = 0
