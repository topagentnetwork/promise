module Infix = struct
  let ( <?> ) c (cmp, x, y) = if c = 0 then cmp x y else c
end
