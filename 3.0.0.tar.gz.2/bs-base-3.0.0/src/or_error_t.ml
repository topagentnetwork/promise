type 'a or_error = ('a, Error.t) Result.t

module type Or_error_t = sig
  include Monad_t.Extended

  val error : Error.t -> 'a t
  val run_or_error_t : 'a t -> 'a or_error m
  val or_error_t : 'a or_error m -> 'a t
end

module Make (M : Monad.Monad) = struct
  include Monad_t.Extend (struct
    type 'a m = 'a M.t
    type 'a t = 'a or_error m

    let return x = M.return @@ Result.Ok x

    let bind ~f m =
      let open Result in
      M.bind
        ~f:(fun x ->
          match x with Ok x' -> f x' | Error e -> M.return @@ Error e)
        m

    let lift m = M.bind ~f:return m
  end)

  let error e = M.return @@ Result.Error e
  let run_or_error_t = Fn.id
  let or_error_t = Fn.id
end
