include Functor_intf

module Extend (F : Functor) : Extended with type 'a t = 'a F.t = struct
  include F

  module Infix = struct
    let ( <$> ) f x = map ~f x
    let ( <$ ) r x = Fn.const r <$> x
    let ( $> ) r x = Fn.const x <$> r
  end

  let void ~f x = map ~f:(fun x -> ignore (f x)) x
end
