module type Monad = sig
  type 'a t

  val return : 'a -> 'a t
  val bind : f:('a -> 'b t) -> 'a t -> 'b t
end

module type Infix = sig
  type 'a t

  include Applicative.Infix with type 'a t := 'a t

  val ( >>= ) : 'a t -> ('a -> 'b t) -> 'b t
  val ( =<< ) : ('a -> 'b t) -> 'a t -> 'b t
  val ( >=> ) : ('a -> 'b t) -> ('b -> 'c t) -> 'a -> 'c t
  val ( <=< ) : ('b -> 'c t) -> ('a -> 'b t) -> 'a -> 'c t
end

module type Extended = sig
  include Monad
  module Infix : Infix with type 'a t := 'a t
  include Applicative.Extended with type 'a t := 'a t and module Infix := Infix

  val lift_m : f:('a -> 'b) -> 'a t -> 'b t
  val lift_m2 : f:('a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t
  val lift_m3 : f:('a -> 'b -> 'c -> 'd) -> 'a t -> 'b t -> 'c t -> 'd t
end

module type S = sig
  module type Monad = Monad
  module type Infix = Infix
  module type Extended = Extended

  module Extend (M : Monad) : Extended with type 'a t = 'a M.t

  module Custom_extend
      (M : Monad)
      (A : Applicative.Applicative with type 'a t = 'a M.t)
      (F : Functor.Functor with type 'a t = 'a M.t) :
    Extended with type 'a t = 'a M.t

  module Make_applicative (M : Monad) :
    Applicative.Applicative with type 'a t = 'a M.t

  module Make_functor (M : Monad) : Functor.Functor with type 'a t = 'a M.t
end
