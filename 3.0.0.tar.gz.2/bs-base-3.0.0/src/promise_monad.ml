type 'a promise = 'a Promise.t

module Promise_monad = struct
  type 'a t = 'a promise

  let return x = Promise.resolved x
  let bind ~f m = Promise.flatMap m f
end

include Monad.Extend (Promise_monad)

let run_promise = Fn.id
