type t =
  | String of string
  (* | Exception of exn *)
  | Of_list of t list
  | Tag_t of string * t
  | Js_exception of Js.Exn.t

exception Error_exception of string

let of_string msg = String msg
let tag ~tag t = Tag_t (tag, t)
let of_list l = Of_list l
let of_js_exn e = Js_exception e

let has_tag ~tag t =
  match t with Tag_t (tag', _) when tag' = tag -> true | _ -> false

let rec to_strings ?(ac = []) t =
  match t with
  | String s -> s :: ac
  | Of_list l ->
      List.fold_left
        (fun ac t ->
          to_strings ~ac:(if List_ext.is_empty ac then ac else "; " :: ac) t)
        ac (List.rev l)
  | Tag_t (tag, t) -> tag :: ": " :: to_strings ~ac t
  | Js_exception e -> Js_exn_ext.to_s e :: ac

let to_string t = List_ext.join ~sep:" " (to_strings t)
let raise t = raise (Error_exception (to_string t))
