type t = Js.Date.t
type fmt_config = {locale: string option [@mel.optional]} [@@deriving jsProperties, getSet]

type timezone_config = {timeZone: string option [@mel.optional]}
[@@deriving jsProperties, getSet]

let default_fmt_config = fmt_config ()
let default_tmz_config = timezone_config ()
let utc_tmz_config = timezone_config ~timeZone:"Etc/UTC" ()

external subDays : t -> int -> t = "date-fns/subDays" [@@mel.module]
external addDays : t -> int -> t = "date-fns/addDays" [@@mel.module]
external subHours : t -> int -> t = "date-fns/subHours" [@@mel.module]
external addHours : t -> int -> t = "date-fns/addHours" [@@mel.module]
external is_after : t -> t -> bool = "date-fns/isAfter" [@@mel.module]
external is_before : t -> t -> bool = "date-fns/isBefore" [@@mel.module]
external startOfDay : t -> t = "date-fns/startOfDay" [@@mel.module]
external endOfDay : t -> t = "date-fns/endOfDay" [@@mel.module]
external parse : string -> t = "date-fns/parse" [@@mel.module]

external difference_in_hours : t -> t -> int = "date-fns/differenceInHours"
  [@@mel.module]

external format' : t -> string -> fmt_config -> string = "date-fns/format"
  [@@mel.module]

external formatToTimeZone : t -> string -> timezone_config -> string
  = "formatToTimeZone"
  [@@mel.module "date-fns-timezone"]

external parseFromTimeZone : string -> timezone_config -> t
  = "parseFromTimeZone"
  [@@mel.module "date-fns-timezone"]

let format ?(fmt_config = default_fmt_config) ~fmt t = format' t fmt fmt_config

let format_to_tmz ?(fmt_config = default_tmz_config) ~fmt t =
  formatToTimeZone t fmt fmt_config

let parse_from_tmz ?(options = default_tmz_config) s =
  parseFromTimeZone s options

let utc_format ~fmt t = formatToTimeZone t fmt utc_tmz_config
let to_string t = Js.Date.toString t
let to_utc_string t = Js.Date.toUTCString t
let get_universal_time t = Js.Date.getTime t
let to_iso_string t = Js.Date.toISOString t
let add_days ~days t = addDays t days
let sub_days ~days t = subDays t days
let add_hours ~hours t = addHours t hours
let sub_hours ~hours t = subHours t hours
let start_of_day t = startOfDay t
let end_of_day t = endOfDay t

let make ?(utc = false) ?year ?month ?date () =
  match (year, month, date) with
  | Some y, Some m, Some d ->
      let year = float_of_int y in
      (* JS month index is 0-based and makes no sense *)
      let month = float_of_int (m - 1) in
      let date = float_of_int d in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYMD ~year ~month ~date
      else Js.Date.makeWithYMD ~year ~month ~date
  | Some y, Some m, None ->
      let year = float_of_int y in
      let month = float_of_int (m - 1) in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYM ~year ~month
      else Js.Date.makeWithYM ~year ~month
  | Some y, None, None ->
      let today = Js.Date.make () in
      let year = float_of_int y in
      let month = Js.Date.getMonth today in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYM ~year ~month 
      else Js.Date.makeWithYM ~year ~month 
  | None, Some m, None ->
      let today = Js.Date.make () in
      let month = float_of_int (m - 1) in
      let year = Js.Date.getFullYear today in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYM ~year ~month 
      else Js.Date.makeWithYM ~year ~month 
  | None, Some m, Some d ->
      let today = Js.Date.make () in
      let month = float_of_int m in
      let date = float_of_int d in
      let year = Js.Date.getFullYear today in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYMD ~year ~month ~date
      else Js.Date.makeWithYMD ~year ~month ~date
  | None, None, Some d ->
      let today = Js.Date.make () in
      let year = Js.Date.getFullYear today in
      let month = Js.Date.getMonth today in
      let date = float_of_int d in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYMD ~year ~month ~date
      else Js.Date.makeWithYMD ~year ~month ~date
  | Some y, None, Some d ->
      let today = Js.Date.make () in
      let month = Js.Date.getMonth today in
      let date = float_of_int d in
      let year = float_of_int y in
      if utc then Js.Date.fromFloat @@ Js.Date.utcWithYMD ~year ~month ~date
      else Js.Date.makeWithYMD ~year ~month ~date 
  | None, None, None -> Js.Date.make ()

let from_unix_timestamp timestamp =
  Js.Date.fromFloat (float_of_int timestamp *. 1000.)

let to_unix_timestamp t = int_of_float @@ (Js.Date.valueOf t /. 1000.)
let today () = make ()
